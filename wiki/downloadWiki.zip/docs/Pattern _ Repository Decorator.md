# Repository Decorator

The decorator pattern is used to extend (decorate) the functionality of Repositories at run-time.
Decorated repositories share the same interface of [Generic Repository](Pattern-_-Generic-Repository)

There are two Repository decorators at the moment : 
* [Auditable Repository](Auditable-Repository)
* [Archivable Repository](ArchivableRepository)
