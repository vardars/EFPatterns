# Unit of work

[Rob Conery](http___wekeroad.com_post_7102729511_a-simple-example-thats-incredibly-complex) says "UnitOfWork is - well it’s a way of transactionally flushing changes to a persistence store (aka Database) ". 

The Unit of work provides the following interface : 

![](Pattern : Unit of work_UnitOfWork.png)