# Archivable entity

Entities marked with _Archivable_ attribute automatically implements the [IArchivable interface](IArchivable-interface).

For example the ArchivableEntity class defined below

{code:csharp}
    [Archivable](Archivable)
    public class ArchivableEntity
    {
        public int Id { get; set; }
        public float Value { get; set; }
    }
{code:csharp}

will end up having this structure after compilation :

![](Pattern : Archivable entity_ArchivableEntityReflector.png)

Note that the [Archivable repository](ArchivableRepository) is a convenient way to query Archivable entities.
