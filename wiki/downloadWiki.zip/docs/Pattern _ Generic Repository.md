# Repository<T>


[Rob Conery](http___wekeroad.com_post_7102729511_a-simple-example-thats-incredibly-complex) says "the Repository Pattern is all about encapsulating calls to your DB as methods to do a thing. These calls are (typically) atomic". 

The generic Repository provides the following interface : 

![](Pattern : Generic Repository_GenericRepository.png)