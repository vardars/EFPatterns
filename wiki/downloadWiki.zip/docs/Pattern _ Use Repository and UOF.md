Given the following model 

{code:csharp}
public class Context : DbContext
{
    public virtual DbSet<Product> Products { get; set; }
    public virtual DbSet<ProductCategory> Categories { get; set; }
 
    public Context()
    {
        Database.SetInitializer(new DropCreateDatabaseAlways<Context>());
    }
}
 
public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int? ProductCategoryId { get; set; }
    public virtual ProductCategory ProductCategory { get; set; }
}
 
public class ProductCategory
{
    public int Id { get; set; }
    public string Name { get; set; }
}
{code:csharp}

In order to manipulate products, we can create a Repository like this : 

{code:csharp}
using(Context ctx = new Context())
{
    DbContextAdapter adapter = new DbContextAdapter(ctx);
    IRepository<Product> productRepo = new Repository<Product>(adp);
}
{code:csharp}

Let's query the database to fetch all products :

{code:csharp}
IEnumerable<Product> lst = productRepo.GetAll();
{code:csharp}

Now, let's bring back the first item whose name begins with "Bike"

{code:csharp}
Product prod = productRepo.First(p => p.Name.StartsWith("Bike"));
{code:csharp}

Using the Single method has the same effect (returns only one element), but throws an exception if multiple items meet the criteria.

{code:csharp}
productRepo.Single(p => p.Name.StartsWith("Roc"))
{code:csharp}

Find method, filters the resultset based on several criteria :

{code:csharp}
IEnumerable<Product> lst = productRepo.Find(
                p => p.Id < 100 && p.Name.Contains("o") && p.Name.Length < 20);
{code:csharp}

All these methods accept an optional set of navigation links between entities materializing joins that will be performed when querying.

{code:csharp}
productRepo.First(p => p.ProductCategoryId != null , p => p.ProductCategory);
{code:csharp}

The above syntax loads the product and its associated category in a single SQL query; This approach avoids the N+1 Selects problem, that might appears when using lazy loading.

Now, when you need to "write" to your db you'll need the Unit of work pattern.

{code:csharp}
using(Context ctx = new Context())
{
   DbContextAdapter adapter = new DbContextAdapter(ctx);
   IRepository<Product> productRepo = new Repository<Product>(adp);
   IUnitOfWork unitOfWork = new UnitOfWork(adp);
   Product p = new Product{Name = "Skateboard"};
   productRepo.Insert(p);
   unitOfWork.Commit();
}
{code:csharp}

As you can see the update and deletion are as simple as that:

{code:csharp}
Product p = productRepo.First(c => c.Name == "Bike");
p.Name = "New bike";
productRepo.Update(p);
 
Product delete = productRepo.First(p => p.Name.StartsWith("To be"));
productRepo.Delete(delete);
 
unitOfWork.Commit();
{code:csharp}