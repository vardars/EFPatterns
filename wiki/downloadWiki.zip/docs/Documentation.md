# Patterns
* [Generic Repository](Pattern-_-Generic-Repository) 
* [Unit of work](Pattern-_-Unit-of-work) 
* [Repository Decorator](Pattern-_-Repository-Decorator)
	* [AuditableRepository](AuditableRepository)
	* [ArchivableRepository](ArchivableRepository)
	* [CacheableRepository](CacheableRepository)
* [Auditable entity](Pattern-_-Auditable-entity)
* [Archivable entity](Pattern-_-Archivable-entity)
* [Tutorial : Using Repository & Unit of work together](Pattern-_-Use-Repository-and-UOF)

# Using EntityFramework.Patterns with an IoC container
* [Unity 2.1](IoC-_-Unity-2.1)
* [Ninject](IoC-_-Ninject)