# Project Description
EntityFramework.Patterns provides ready to use patterns that will leverage your development with Entity Framework 6.
Older versions, support EF 4 and 5.

# Quickstart
EntityFramework.Patterns is available on [NuGet](http://nuget.codeplex.com/). You can reference EntityFramework.Patterns in your project in VS.NET by either 
* using Add Library Package Reference menu (right click References > Add Library Package Reference) or 
* Package Manager Console (Tools > Library Package Manager > Package Manager Console). 
If you use the latter approach, type this to the command-line: 

{code:powershell}
Install-Package EntityFramework.Patterns
{code:powershell}

If you're using VS 2010 you might have to install [NuGet Package Manager extension](http://nuget.codeplex.com/releases/view/64974) for VS.NET 2010.

# Available patterns

* [Generic Repository](Pattern-_-Generic-Repository)
* [Unit of work](Pattern-_-Unit-of-work)
* [Repository Decorator](Pattern-_-Repository-Decorator)
	* [AuditableRepository](AuditableRepository)
	* [ArchivableRepository](ArchivableRepository)
	* [CacheableRepository](CacheableRepository)
* [Auditable entity](Pattern-_-Auditable-entity)
* [Archivable entity](Pattern-_-Archivable-entity)

# First steps

Check out the documentation and follow this [tutorial](Pattern-_-Use-Repository-and-UOF).