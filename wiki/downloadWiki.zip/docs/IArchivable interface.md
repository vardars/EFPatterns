# IArchivable interface 

This interface is a convenient way to track when and who has deleted an entity.

{code:csharp}
    public interface IArchivable
    {
        string DeletedBy { get; set; }
        DateTime? Deleted { get; set; }
    }
{code:csharp}